Hi!

These DLLs are from SetGPU, an experimental project detailed here:
https://github.com/pinumbernumber/SetGPU

You should not use these files without first reading and following the
instructions found at the link above.

I strongly recommend that you DO NOT use these files in multiplayer games
for now. You do so at your own risk- you may well get banned by overzealous
anticheat software.

Please don't share/rehost these DLLs directly- instead, please share the
GitHub link above.

Thank you for testing SetGPU!
